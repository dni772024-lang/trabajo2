# Guía de Migración a PostgreSQL

## 📋 Resumen
Esta guía te ayudará a migrar tu aplicación de `localStorage` a **PostgreSQL**.

---

## 🗄️ 1. Instalación de PostgreSQL

### Windows
1. Descarga PostgreSQL desde: https://www.postgresql.org/download/windows/
2. Ejecuta el instalador
3. Anota el password que configures para el usuario `postgres`
4. Asegúrate de instalar **pgAdmin** (viene incluido)

### macOS
```bash
brew install postgresql
brew services start postgresql
```

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

---

## 🔧 2. Crear la Base de Datos

### Opción A: Usando pgAdmin (Interfaz Gráfica)
1. Abre **pgAdmin**
2. Conecta al servidor PostgreSQL local
3. Click derecho en "Databases" → "Create" → "Database"
4. Nombre: `equipment_control`
5. Click "Save"

### Opción B: Usando línea de comandos
```bash
# Acceder a PostgreSQL
psql -U postgres

# Crear la base de datos
CREATE DATABASE equipment_control;

# Salir
\q
```

---

## 📊 3. Ejecutar el Script SQL

### Opción A: Usando pgAdmin
1. Abre **pgAdmin**
2. Navega a: Servers → PostgreSQL → Databases → equipment_control
3. Click en "Query Tool" (icono de rayo)
4. Abre el archivo `database-schema.sql`
5. Click en el botón "Execute" (▶️)

### Opción B: Usando línea de comandos
```bash
psql -U postgres -d equipment_control -f database-schema.sql
```

---

## 📦 4. Instalar Dependencias de Node.js

```bash
npm install pg dotenv
npm install --save-dev @types/pg
```

O si usas yarn:
```bash
yarn add pg dotenv
yarn add -D @types/pg
```

---

## ⚙️ 5. Configurar Variables de Entorno

1. Copia el archivo `.env.example` a `.env`:
```bash
cp .env.example .env
```

2. Edita el archivo `.env` con tus credenciales:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=equipment_control
DB_USER=postgres
DB_PASSWORD=tu_password_real
```

---

## 🔄 6. Actualizar el Código de la Aplicación

### Paso 1: Cambiar las importaciones

**ANTES:**
```typescript
import { storage } from './services/storage';
```

**DESPUÉS:**
```typescript
import { storagePostgres as storage } from './services/storagePostgres';
```

### Paso 2: Cambiar todas las llamadas a `async/await`

Como PostgreSQL es asíncrono, necesitas actualizar todas las llamadas:

**ANTES:**
```typescript
const users = storage.getUsers();
```

**DESPUÉS:**
```typescript
const users = await storage.getUsers();
```

### Paso 3: Ejemplos de cambios comunes

#### En componentes de React:
```typescript
// ANTES
useEffect(() => {
  const data = storage.getEquipment();
  setEquipment(data);
}, []);

// DESPUÉS
useEffect(() => {
  const loadData = async () => {
    const data = await storage.getEquipment();
    setEquipment(data);
  };
  loadData();
}, []);
```

#### En funciones de manejo:
```typescript
// ANTES
const handleSave = () => {
  storage.addEquipment(newEquipment);
  alert('Guardado!');
};

// DESPUÉS
const handleSave = async () => {
  try {
    await storage.addEquipment(newEquipment);
    alert('Guardado!');
  } catch (error) {
    console.error('Error:', error);
    alert('Error al guardar');
  }
};
```

---

## 🚀 7. Inicializar la Aplicación

Actualiza tu archivo principal (App.tsx o index.tsx):

```typescript
import { storagePostgres } from './services/storagePostgres';

// Al inicio de la aplicación
async function initApp() {
  try {
    await storagePostgres.init();
    console.log('✅ Base de datos conectada');
  } catch (error) {
    console.error('❌ Error al conectar con la base de datos:', error);
  }
}

initApp();
```

---

## 🧪 8. Verificar la Conexión

Crea un script de prueba:

```typescript
// test-db.ts
import Database from './services/database';

async function testConnection() {
  const isConnected = await Database.testConnection();
  if (isConnected) {
    console.log('✅ Conexión exitosa a PostgreSQL');
  } else {
    console.log('❌ No se pudo conectar a PostgreSQL');
  }
  await Database.close();
}

testConnection();
```

Ejecuta:
```bash
npx ts-node test-db.ts
```

---

## 📝 9. Datos Iniciales

El script SQL ya incluye:
- ✅ 1 usuario administrador (username: `admin.pro.001`, password: `Admin123`)
- ✅ 3 categorías de equipos
- ✅ 4 empleados de ejemplo
- ✅ 3 equipos de ejemplo

---

## 🔍 10. Consultas Útiles

### Ver todos los usuarios:
```sql
SELECT * FROM users;
```

### Ver equipos disponibles:
```sql
SELECT * FROM equipment WHERE status = 'Disponible';
```

### Ver préstamos activos:
```sql
SELECT * FROM loans WHERE status = 'active';
```

### Contar equipos por categoría:
```sql
SELECT category, COUNT(*) 
FROM equipment 
GROUP BY category;
```

---

## ⚠️ 11. Solución de Problemas Comunes

### Error: "password authentication failed"
- Verifica que el password en `.env` sea correcto
- Revisa el archivo `pg_hba.conf` de PostgreSQL

### Error: "database does not exist"
- Asegúrate de haber creado la base de datos `equipment_control`

### Error: "relation does not exist"
- Ejecuta el script `database-schema.sql` completo

### Error de conexión rechazada
```bash
# Verifica que PostgreSQL esté corriendo
# Windows:
services.msc (busca PostgreSQL)

# macOS:
brew services list

# Linux:
sudo systemctl status postgresql
```

---

## 📚 12. Recursos Adicionales

- [Documentación de PostgreSQL](https://www.postgresql.org/docs/)
- [node-postgres (pg)](https://node-postgres.com/)
- [Tutorial de PostgreSQL](https://www.postgresqltutorial.com/)

---

## 🎯 Checklist de Migración

- [ ] PostgreSQL instalado
- [ ] Base de datos `equipment_control` creada
- [ ] Script SQL ejecutado exitosamente
- [ ] Dependencias npm instaladas (`pg`, `dotenv`)
- [ ] Archivo `.env` configurado
- [ ] Importaciones actualizadas a `storagePostgres`
- [ ] Todas las llamadas convertidas a `async/await`
- [ ] Prueba de conexión exitosa
- [ ] Aplicación funcionando correctamente

---

## 💡 Notas Importantes

1. **Backup**: Antes de migrar, exporta tus datos de `localStorage` si es necesario
2. **Seguridad**: Nunca subas el archivo `.env` a git (ya está en `.gitignore`)
3. **Producción**: En producción, usa variables de entorno del servidor, no archivos `.env`
4. **Contraseñas**: El usuario admin inicial tiene password `Admin123` - cámbialo inmediatamente

---

¡Listo! Ahora tu aplicación usa PostgreSQL en lugar de localStorage. 🎉
